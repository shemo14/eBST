export default {
    url: 'https://shams.arabsdesign.com/eBST-backend/api/',
};